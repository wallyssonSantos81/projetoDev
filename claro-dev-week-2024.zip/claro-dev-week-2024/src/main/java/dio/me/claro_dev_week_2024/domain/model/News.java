package dio.me.claro_dev_week_2024.domain.model;

import jakarta.persistence.Entity;

@Entity(name = "tb_news")
public class News extends BaseItem {

   
}
