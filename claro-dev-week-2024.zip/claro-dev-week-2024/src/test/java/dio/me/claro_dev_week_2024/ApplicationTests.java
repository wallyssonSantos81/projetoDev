package dio.me.claro_dev_week_2024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaroDevWeek2024ApplicationTests {

	@Test
	void contextLoads() {
	}

}
